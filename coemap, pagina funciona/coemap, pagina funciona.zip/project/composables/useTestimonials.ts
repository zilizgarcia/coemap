import { ref } from 'vue'
import type { Testimonial } from '~/types/testimonial'

export const useTestimonials = () => {
  const featuredTestimonials = ref<Testimonial[]>([
    {
      id: 1,
      name: 'Sarah Thompson',
      location: 'New York, NY',
      content: 'This platform has been a lifeline during difficult times. The resources and support I found here helped me navigate through anxiety and stress with confidence.',
      image: '/images/testimonials/sarah.jpg',
      rating: 5
    },
    {
      id: 2,
      name: 'David Chen',
      location: 'San Francisco, CA',
      content: 'The community here is incredibly supportive and understanding. I've learned valuable coping strategies and made meaningful connections with others on similar journeys.',
      image: '/images/testimonials/david.jpg',
      rating: 5
    }
  ])

  const testimonials = ref<Testimonial[]>([
    {
      id: 3,
      name: 'Emily Rodriguez',
      location: 'Miami, FL',
      content: 'The meditation resources have transformed my daily routine. I feel more centered and peaceful.',
      image: '/images/testimonials/emily.jpg',
      rating: 5
    },
    {
      id: 4,
      name: 'Michael Johnson',
      location: 'Chicago, IL',
      content: 'The support groups here have been instrumental in my healing journey.',
      image: '/images/testimonials/michael.jpg',
      rating: 4
    },
    {
      id: 5,
      name: 'Lisa Wong',
      location: 'Seattle, WA',
      content: 'Excellent resources and a very supportive community. Highly recommended!',
      image: '/images/testimonials/lisa.jpg',
      rating: 5
    }
  ])

  return {
    featuredTestimonials,
    testimonials
  }
}