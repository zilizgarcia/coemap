<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-4xl font-bold text-gray-900 mb-8">Testimonials</h1>

    <!-- Featured Testimonials -->
    <section class="mb-12">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <TestimonialCard
          v-for="testimonial in featuredTestimonials"
          :key="testimonial.id"
          v-bind="testimonial"
          class="p-8"
          featured
        />
      </div>
    </section>

    <!-- Regular Testimonials -->
    <section>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <TestimonialCard
          v-for="testimonial in testimonials"
          :key="testimonial.id"
          v-bind="testimonial"
          class="p-6"
        />
      </div>
    </section>
  </div>
</template>

<script setup>
import { useTestimonials } from '~/composables/useTestimonials'

const { featuredTestimonials, testimonials } = useTestimonials()
</script>