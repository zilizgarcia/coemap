<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-4xl font-bold text-gray-900 mb-8">Resources & Tools</h1>

    <!-- Resource Categories -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
      <div v-for="(category, index) in categories" :key="index" 
           class="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
        <h2 class="text-xl font-semibold mb-4">{{ category.title }}</h2>
        <p class="text-gray-600 mb-4">{{ category.description }}</p>
        <ul class="space-y-2">
          <li v-for="(item, itemIndex) in category.items" :key="itemIndex">
            <NuxtLink :to="item.link" class="text-indigo-600 hover:text-indigo-500 flex items-center">
              <ArrowRightIcon class="h-4 w-4 mr-2" />
              {{ item.title }}
            </NuxtLink>
          </li>
        </ul>
      </div>
    </div>

    <!-- Featured Tools -->
    <section class="mb-12">
      <h2 class="text-2xl font-bold text-gray-900 mb-6">Featured Tools</h2>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div v-for="(tool, index) in tools" :key="index" 
             class="bg-white rounded-lg shadow-sm p-6">
          <h3 class="text-xl font-semibold mb-2">{{ tool.title }}</h3>
          <p class="text-gray-600 mb-4">{{ tool.description }}</p>
          <NuxtLink :to="tool.link" 
                   class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
            Try Now
          </NuxtLink>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ArrowRightIcon } from '@heroicons/vue/24/solid'

const categories = [
  {
    title: 'Self-Help Guides',
    description: 'Step-by-step guides for managing common emotional challenges.',
    items: [
      { title: 'Stress Management', link: '/resources/stress' },
      { title: 'Anxiety Relief', link: '/resources/anxiety' },
      { title: 'Mindfulness Practices', link: '/resources/mindfulness' }
    ]
  },
  {
    title: 'Interactive Tools',
    description: 'Practical tools and exercises for emotional wellbeing.',
    items: [
      { title: 'Mood Tracker', link: '/tools/mood-tracker' },
      { title: 'Breathing Exercises', link: '/tools/breathing' },
      { title: 'Journaling Tool', link: '/tools/journal' }
    ]
  },
  {
    title: 'Support Resources',
    description: 'Connect with others and find professional help.',
    items: [
      { title: 'Support Groups', link: '/resources/groups' },
      { title: 'Crisis Hotlines', link: '/resources/crisis' },
      { title: 'Find a Therapist', link: '/resources/therapists' }
    ]
  }
]

const tools = [
  {
    title: 'Guided Meditation',
    description: 'Access our collection of calming meditation sessions.',
    link: '/tools/meditation'
  },
  {
    title: 'Mood Journal',
    description: 'Track your emotional journey and identify patterns.',
    link: '/tools/journal'
  }
]
</script>