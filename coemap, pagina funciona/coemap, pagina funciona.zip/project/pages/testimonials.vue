<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-4xl font-bold text-gray-900 mb-8">Testimonials</h1>

    <!-- Featured Testimonials -->
    <section class="mb-12">
      <TestimonialList
        :testimonials="featuredTestimonials"
        featured
        grid-class="md:grid-cols-2 gap-8"
        card-class="p-8"
      />
    </section>

    <!-- Regular Testimonials -->
    <section>
      <TestimonialList :testimonials="testimonials" />
    </section>
  </div>
</template>

<script setup>
import { useTestimonials } from '~/composables/useTestimonials'

const { featuredTestimonials, testimonials } = useTestimonials()
</script>