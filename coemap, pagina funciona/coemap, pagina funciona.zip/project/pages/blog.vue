<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <h1 class="text-4xl font-bold text-gray-900 mb-8">Blog</h1>

    <!-- Featured Post -->
    <div v-if="featuredPost" class="mb-12">
      <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <img :src="featuredPost.image" :alt="featuredPost.title" class="w-full h-96 object-cover">
        <div class="p-6">
          <div class="flex items-center mb-4">
            <span class="bg-indigo-100 text-indigo-800 text-sm font-medium px-3 py-1 rounded-full">
              {{ featuredPost.category }}
            </span>
            <span class="text-gray-500 text-sm ml-4">{{ featuredPost.date }}</span>
          </div>
          <h2 class="text-2xl font-bold mb-4">{{ featuredPost.title }}</h2>
          <p class="text-gray-600 mb-4">{{ featuredPost.excerpt }}</p>
          <NuxtLink :to="featuredPost.link" class="text-indigo-600 hover:text-indigo-500 font-medium">
            Read More →
          </NuxtLink>
        </div>
      </div>
    </div>

    <!-- Blog Posts Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      <article v-for="post in posts" :key="post.id" class="bg-white rounded-lg shadow-sm overflow-hidden">
        <img :src="post.image" :alt="post.title" class="w-full h-48 object-cover">
        <div class="p-6">
          <div class="flex items-center mb-4">
            <span class="bg-indigo-100 text-indigo-800 text-sm font-medium px-3 py-1 rounded-full">
              {{ post.category }}
            </span>
            <span class="text-gray-500 text-sm ml-4">{{ post.date }}</span>
          </div>
          <h3 class="text-xl font-bold mb-2">{{ post.title }}</h3>
          <p class="text-gray-600 mb-4">{{ post.excerpt }}</p>
          <NuxtLink :to="post.link" class="text-indigo-600 hover:text-indigo-500 font-medium">
            Read More →
          </NuxtLink>
        </div>
      </article>
    </div>
  </div>
</template>

<script setup>
const featuredPost = {
  id: 1,
  title: 'Understanding and Managing Anxiety in Daily Life',
  excerpt: 'Learn practical strategies for managing anxiety and building resilience in your everyday life.',
  image: '/images/blog/featured.jpg',
  category: 'Mental Health',
  date: 'March 15, 2024',
  link: '/blog/managing-anxiety'
}

const posts = [
  {
    id: 2,
    title: 'The Power of Mindful Breathing',
    excerpt: 'Discover how simple breathing exercises can transform your stress response.',
    image: '/images/blog/breathing.jpg',
    category: 'Mindfulness',
    date: 'March 12, 2024',
    link: '/blog/mindful-breathing'
  },
  {
    id: 3,
    title: 'Building Healthy Relationships',
    excerpt: 'Tips for nurturing meaningful connections in your life.',
    image: '/images/blog/relationships.jpg',
    category: 'Relationships',
    date: 'March 10, 2024',
    link: '/blog/healthy-relationships'
  },
  {
    id: 4,
    title: 'Self-Care Practices for Busy People',
    excerpt: 'Simple ways to incorporate self-care into your daily routine.',
    image: '/images/blog/self-care.jpg',
    category: 'Self-Care',
    date: 'March 8, 2024',
    link: '/blog/self-care-practices'
  }
]
</script>