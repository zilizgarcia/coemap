<template>
  <div>
    <!-- Hero Section -->
    <section class="relative bg-white overflow-hidden">
      <div class="max-w-7xl mx-auto">
        <div class="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <main class="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div class="sm:text-center lg:text-left">
              <h1 class="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                <span class="block">Find Peace and</span>
                <span class="block text-indigo-600">Support Here</span>
              </h1>
              <p class="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                Your journey to emotional wellbeing starts here. We provide a safe space for support, growth, and healing.
              </p>
              <div class="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div class="rounded-md shadow">
                  <NuxtLink to="/resources" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10">
                    Get Started
                  </NuxtLink>
                </div>
                <div class="mt-3 sm:mt-0 sm:ml-3">
                  <NuxtLink to="/contact" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 md:py-4 md:text-lg md:px-10">
                    Talk to Someone
                  </NuxtLink>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </section>

    <!-- Featured Resources -->
    <section class="bg-gray-50 py-12">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-3xl font-extrabold text-gray-900 text-center mb-8">
          Featured Resources
        </h2>
        <div class="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div v-for="(resource, index) in featuredResources" :key="index" class="bg-white rounded-lg shadow-sm p-6">
            <h3 class="text-xl font-semibold mb-2">{{ resource.title }}</h3>
            <p class="text-gray-600">{{ resource.description }}</p>
            <NuxtLink :to="resource.link" class="mt-4 inline-flex items-center text-indigo-600 hover:text-indigo-500">
              Learn more
              <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
              </svg>
            </NuxtLink>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
const featuredResources = [
  {
    title: 'Meditation Guides',
    description: 'Discover peace through our guided meditation sessions.',
    link: '/resources/meditation'
  },
  {
    title: 'Stress Management',
    description: 'Learn effective techniques to manage daily stress.',
    link: '/resources/stress'
  },
  {
    title: 'Support Groups',
    description: 'Connect with others in a safe, supportive environment.',
    link: '/resources/groups'
  }
]
</script>