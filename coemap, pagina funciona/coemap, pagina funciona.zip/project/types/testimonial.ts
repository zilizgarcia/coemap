export interface Testimonial {
  id: number
  name: string
  location: string
  content: string
  image: string
  rating: number
}